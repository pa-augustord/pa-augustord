/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    private static final String URL = "jdbc:mysql://localhost:3306/seu_banco_de_dados"; // Altere para o seu banco de dados
    private static final String USER = "seu_usuario"; // Altere para seu usuário do banco de dados
    private static final String PASSWORD = "sua_senha"; // Altere para sua senha do banco de dados

    public static Connection getConnection() throws SQLException {
        // Registre o driver (opcional se você estiver usando uma versão recente)
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL não encontrado.", e);
        }
        
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}


