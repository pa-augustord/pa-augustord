/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

public class MainApp {
    public static void main(String[] args) {
        // Instanciar o DAO
        VisitanteDAO visitanteDAO = new VisitanteDAO();

        // Criar um novo visitante
        Visitante visitante = new Visitante("Maria", "maria@example.com", "Mulher", "2024-09-28");

        // Adicionar o visitante ao banco de dados
        visitanteDAO.adicionarVisitante(visitante);
    }
}

