/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author PA
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class VisitanteDAO {
    
    public void adicionarVisitante(Visitante visitante) {
        String sql = "INSERT INTO visitantes (nome, email, tipo_visitante, data_registro) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = Database.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setString(1, visitante.getNome());
            pstmt.setString(2, visitante.getEmail());
            pstmt.setString(3, visitante.getTipoVisitante());
            pstmt.setDate(4, java.sql.Date.valueOf(visitante.getDataDoRegistro()));
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Outros métodos, como listarVisitantes...
}

